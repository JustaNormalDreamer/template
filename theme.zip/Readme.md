<!-- Photographs -->
Photographs from www.unspash.com

css used Tailwindcss

<!-- Built Time -->
built within 2 hours.

.No JS used yet!

<!-- After couple of mins  -->
Jquery added inorder to make js easier for scroll, counters