module.exports = {
  theme: {
    container: {
      center: true,
      padding: '1rem'
    }
  },
  variants: {},
  plugins: []
}
